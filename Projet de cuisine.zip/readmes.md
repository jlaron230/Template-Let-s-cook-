Fichier Readme

#Section HEADER -
Création du menu de navigation et avec le logo et les links.

#Section Main -
Création des cartes de menu en responsive avec les éléments basics, shrink et grow en flex. Ajout du badge sur chacune des cartes

#Section Footer -
Création du Footer avec plusieurs section pour les links, réseaux sociaux et le formulaire de newsletter.

#Page Formulaire -
Création d'une page pour un formulaire de contact via le lien (Contact dans le footer, pour y acceder)

-- Le site est responsive est s'adapte à tous les formats.